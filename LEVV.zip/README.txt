REQUIREMENTS
-------------------------------------------------
THE GAME REQUIRES 2 PLAYERS AND 2 CONTROLLERS

THE GAME WON'T LET YOU PAST THE TITLE SCREEN
UNLESS YOU HAVE AT LEAST TWO CONTROLLERS CONNECTED
---------------------------------------------------



CONTROLS
---------------------------------------------------
A - Jump
X - Short Range Attack
B - Long Range Attack

Left stick - Player Movement
Right Stick - Orb Movement

Shoulder Buttons - Conjure shield wall
Trigger Buttons  - Dash

Player can also jump by clicking in the left stick
----------------------------------------------------


REGARDING ORB MOVEMENT
----------------------------------------------------
Right stick creates and controls a "ghost" of the orb
The ghost moves much faster than the orb itself
Orb will follow the ghost